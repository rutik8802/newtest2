from django.shortcuts import render
from django.contrib.auth.forms import UserCreationForm
from django.http import HttpResponse

# def Home(request):
#     return render(request,'index.html')
# def videos(request):
#     return render(request,'Services.html')

# def Signup(request):
#     return render(request,'Signup.html')
# def play(request):
#     return render(request,'play.html')

# def caro(request):
#     return render(request, 'caro.html')