from django.contrib import admin
from .models import video_content,Eat_better
# Register your models here

admin.site.register(video_content),
admin.site.register(Eat_better)
